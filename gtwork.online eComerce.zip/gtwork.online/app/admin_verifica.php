<?php
    if($Spermissao != "admin"){
        header("Location: ../index.php");    
    }


?>
